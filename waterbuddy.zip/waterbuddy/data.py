"""WaterBuddy – static reference data (no Streamlit code here)."""

# NOTE: Before submitting, open each USDA FoodData Central link and confirm the
# ID really matches the food named. Update the ID or the percentage if it does not.

DEFAULT_AGE_GROUP = "13–18 years (Teens)"

AGE_GROUPS = {
    "6–12 years (Children)": {
        "goal": 1600,
        "note": "Suggested illustrative daily goal (1600 ml). Educational reference only, not medical advice.",
    },
    "13–18 years (Teens)": {
        "goal": 2100,
        "note": "Illustrative daily goal (2100 ml) for school project use, not a clinical prescription.",
    },
    "19–64 years (Adults)": {
        "goal": 2500,
        "note": "Suggested illustrative daily goal (2500 ml). General wellness reference, not medical advice.",
    },
    "65+ years (Older Adults)": {
        "goal": 2000,
        "note": "Illustrative daily goal (2000 ml) for educational demonstration, not medical guidance.",
    },
}

FDC_URL = "https://fdc.nal.usda.gov/"

FOOD_DATA = [
    {
        "name": "Plain Water",
        "water_pct": 100.0,
        "default_serving_g": 250,
        "source": "USDA FoodData Central (FDC ID: 173647)",
        "source_url": FDC_URL,
    },
    {
        "name": "Coconut Water (unsweetened)",
        "water_pct": 95.0,
        "default_serving_g": 240,
        "source": "USDA FoodData Central (FDC ID: 171686)",
        "source_url": FDC_URL,
    },
    {
        "name": "Cucumber (raw, with peel)",
        "water_pct": 95.2,
        "default_serving_g": 100,
        "source": "USDA FoodData Central (FDC ID: 168409)",
        "source_url": FDC_URL,
    },
    {
        "name": "Watermelon (raw)",
        "water_pct": 91.5,
        "default_serving_g": 150,
        "source": "USDA FoodData Central (FDC ID: 167765)",
        "source_url": FDC_URL,
    },
    {
        "name": "Vegetable Broth / Clear Soup",
        "water_pct": 92.0,
        "default_serving_g": 240,
        "source": "USDA FoodData Central (FDC ID: 171557)",
        "source_url": FDC_URL,
    },
    {
        "name": "Milk (whole, fluid)",
        "water_pct": 88.1,
        "default_serving_g": 240,
        "source": "USDA FoodData Central (FDC ID: 746782)",
        "source_url": FDC_URL,
    },
    {
        "name": "Orange (raw, navels)",
        "water_pct": 86.8,
        "default_serving_g": 140,
        "source": "USDA FoodData Central (FDC ID: 746771)",
        "source_url": FDC_URL,
    },
    {
        "name": "Apple (raw, with skin)",
        "water_pct": 85.6,
        "default_serving_g": 180,
        "source": "USDA FoodData Central (FDC ID: 171688)",
        "source_url": FDC_URL,
    },
    {
        "name": "Plain Yogurt (whole milk)",
        "water_pct": 87.9,
        "default_serving_g": 170,
        "source": "USDA FoodData Central (FDC ID: 171284)",
        "source_url": FDC_URL,
    },
    {
        "name": "Cooked Lentils (Dal, boiled)",
        "water_pct": 69.6,
        "default_serving_g": 150,
        "source": "USDA FoodData Central (FDC ID: 172421)",
        "source_url": FDC_URL,
    },
    {
        "name": "Cooked White Rice (steamed)",
        "water_pct": 68.4,
        "default_serving_g": 150,
        "source": "USDA FoodData Central (FDC ID: 168878)",
        "source_url": FDC_URL,
    },
    {
        "name": "Banana (raw)",
        "water_pct": 74.9,
        "default_serving_g": 120,
        "source": "USDA FoodData Central (FDC ID: 173944)",
        "source_url": FDC_URL,
    },
    {
        "name": "Whole Wheat Roti / Chapati",
        "water_pct": 34.0,
        "default_serving_g": 45,
        "source": "USDA FoodData Central (FDC ID: 172688)",
        "source_url": FDC_URL,
    },
    {
        "name": "Potato Chips (salted, plain)",
        "water_pct": 1.9,
        "default_serving_g": 30,
        "source": "USDA FoodData Central (FDC ID: 174692)",
        "source_url": FDC_URL,
    },
    {
        "name": "Roasted Almonds",
        "water_pct": 2.4,
        "default_serving_g": 28,
        "source": "USDA FoodData Central (FDC ID: 170567)",
        "source_url": FDC_URL,
    },
    {
        "name": "Homemade Masala Khichdi (Unverified Recipe)",
        "water_pct": None,  # Deliberately missing -> shown as "Data unavailable"
        "default_serving_g": 200,
        "source": "USDA FoodData Central (Custom preparation not indexed)",
        "source_url": FDC_URL,
    },
]

INFUSE_INGREDIENTS = [
    {
        "name": "Lemon (Nimbu)",
        "category": "Citrus & Fruit",
        "nutrients": "Vitamin C, citric acid, small amounts of potassium and flavonoids",
        "taste": "Bright, tangy, citrusy, refreshing",
        "use": "Squeeze half a fresh lemon or drop 2–3 thin rounds into 500 ml of cool or warm water.",
        "precautions": "Citric acid can gradually wear down tooth enamel over time; rinsing your mouth with plain water afterwards or using a straw helps protect teeth.",
        "claims": [
            {
                "claim": "Adds Vitamin C and natural citrus flavour that can make plain water more appealing to drink.",
                "evidence": "Well supported",
            },
            {
                "claim": "Citric acid in lemon juice can increase urinary citrate levels in some individuals.",
                "evidence": "Limited evidence",
            },
            {
                "claim": "Drinking warm lemon water melts body fat or flushes toxins from organs.",
                "evidence": "Insufficient evidence",
            },
        ],
        "source_name": "USDA FoodData Central – Lemon Juice, Raw",
        "source_url": FDC_URL,
    },
    {
        "name": "Mint Leaves (Pudina)",
        "category": "Herbs & Leaves",
        "nutrients": "Trace vitamin A, antioxidants (rosmarinic acid), volatile essential oils (menthol)",
        "taste": "Cool, crisp, herbal, mildly sweet",
        "use": "Gently crush 6–8 washed fresh mint leaves and steep in a pitcher of chilled water for 30 minutes.",
        "precautions": "Menthol may relax the lower esophageal sphincter and trigger heartburn in people prone to acid reflux (GERD).",
        "claims": [
            {
                "claim": "Menthol activates cold-sensitive receptors in the mouth, creating a cooling sensory effect.",
                "evidence": "Well supported",
            },
            {
                "claim": "Concentrated peppermint oil capsules can ease occasional digestive spasms (water infusions contain far lower levels).",
                "evidence": "Limited evidence",
            },
            {
                "claim": "Mint-infused water cures chronic indigestion or purifies the bloodstream.",
                "evidence": "Insufficient evidence",
            },
        ],
        "source_name": "NCCIH – Peppermint Oil & Herb Overview",
        "source_url": "https://www.nccih.nih.gov/health/peppermint-oil",
    },
    {
        "name": "Cucumber Slices (Kheera)",
        "category": "Vegetables & Refreshers",
        "nutrients": "Over 95% water, trace vitamin K, potassium, and cucurbitacins",
        "taste": "Mild, clean, spa-like, subtle vegetal freshness",
        "use": "Add 5–6 thin ribbons or rounds of washed cucumber to 1 litre of chilled water for 1–2 hours.",
        "precautions": "Discard slices after 24 hours even if refrigerated to prevent spoilage; wash peel thoroughly.",
        "claims": [
            {
                "claim": "Provides mild pleasant flavour with virtually zero added sugar or calories.",
                "evidence": "Well supported",
            },
            {
                "claim": "Eating the cucumber slices after drinking the water contributes a modest amount of dietary hydration.",
                "evidence": "Well supported",
            },
            {
                "claim": "Cucumber water alone reverses skin ageing or clears acne.",
                "evidence": "Insufficient evidence",
            },
        ],
        "source_name": "USDA FoodData Central – Cucumber, With Peel, Raw",
        "source_url": FDC_URL,
    },
    {
        "name": "Chia Seeds (Sabja / Chia)",
        "category": "Seeds & Spices",
        "nutrients": "Soluble and insoluble dietary fibre, plant omega-3 (ALA), calcium, magnesium, protein",
        "taste": "Neutral, mild nutty note with a soft gelatinous texture when soaked",
        "use": "Stir 1 teaspoon of chia seeds into 250 ml of water and let sit for 15–20 minutes until a gel coat forms.",
        "precautions": "Always soak chia seeds thoroughly before consuming; eating dry seeds followed by water can cause them to swell in the throat.",
        "claims": [
            {
                "claim": "When consumed whole in water, soaked chia seeds provide soluble fibre that absorbs up to 10–12 times their weight in liquid.",
                "evidence": "Well supported",
            },
            {
                "claim": "Fibre from soaked seeds may promote a temporary feeling of fullness as part of a balanced meal.",
                "evidence": "Limited evidence",
            },
            {
                "claim": "Chia seed water causes rapid targeted belly-fat loss regardless of overall diet.",
                "evidence": "Insufficient evidence",
            },
        ],
        "source_name": "Harvard T.H. Chan School of Public Health – Chia Seeds",
        "source_url": "https://nutritionsource.hsph.harvard.edu/food-features/chia-seeds/",
    },
    {
        "name": "Fennel Seeds (Saunf)",
        "category": "Seeds & Spices",
        "nutrients": "Aromatic essential oils (anethole), trace manganese, iron, calcium, and fibre (if chewed)",
        "taste": "Naturally sweet, anise-like, mild liquorice aroma",
        "use": "Steep 1 teaspoon of lightly crushed fennel seeds in hot water for 10 minutes or overnight in room-temperature water, then strain.",
        "precautions": "Safe in culinary amounts; people with allergies to carrots, celery, or mugwort may experience cross-reactivity.",
        "claims": [
            {
                "claim": "Anethole gives water a naturally sweet aroma without adding sugar or artificial sweeteners.",
                "evidence": "Well supported",
            },
            {
                "claim": "Traditionally used after meals as a mild carminative to comfort the stomach.",
                "evidence": "Limited evidence",
            },
            {
                "claim": "Saunf water regulates hormone disorders or treats metabolic diseases.",
                "evidence": "Insufficient evidence",
            },
        ],
        "source_name": "USDA FoodData Central – Spices, Fennel Seed",
        "source_url": FDC_URL,
    },
    {
        "name": "Cumin Seeds (Jeera)",
        "category": "Seeds & Spices",
        "nutrients": "Cuminaldehyde (aromatic compound), iron, trace antioxidants",
        "taste": "Warm, earthy, savoury, slightly nutty",
        "use": "Simmer 1/2 to 1 teaspoon of cumin seeds in 300 ml of water for 5 minutes, let cool to warm or room temperature, and strain.",
        "precautions": "Very concentrated infusions on an empty stomach may feel warming or mildly irritating for sensitive stomachs.",
        "claims": [
            {
                "claim": "Boiling cumin releases aromatic compounds that create a savoury, sugar-free warm beverage.",
                "evidence": "Well supported",
            },
            {
                "claim": "Preliminary laboratory studies suggest cumin extracts stimulate digestive enzyme activity.",
                "evidence": "Limited evidence",
            },
            {
                "claim": "Drinking jeera water every morning cures diabetes or melts fat without lifestyle changes.",
                "evidence": "Insufficient evidence",
            },
        ],
        "source_name": "USDA FoodData Central – Spices, Cumin Seed",
        "source_url": FDC_URL,
    },
]

HYDRATION_TIPS = [
    {
        "title": "Anchor Sips to Daily Routines",
        "body": "Instead of waiting until you feel parched, pair a glass of water with habits you already do—like waking up, sitting down to study, or returning home from school.",
        "tag": "Habit Building",
    },
    {
        "title": "Keep Water Within Arm's Reach",
        "body": "Visual reminders work wonders. Keeping a refillable bottle on your study desk makes taking small, regular sips effortless while working on assignments.",
        "tag": "Environment",
    },
    {
        "title": "Eat Your Water Too",
        "body": "Fruits and vegetables like cucumber, watermelon, oranges, and tomatoes are over 85% water and contribute meaningfully to your daily fluid intake.",
        "tag": "Nutrition",
    },
    {
        "title": "Adjust for Warm Weather & Sports",
        "body": "On hot afternoons or during physical education and sports practice, your body loses more water through sweat. Pack an extra bottle on active days.",
        "tag": "Activity",
    },
    {
        "title": "Flavour Naturally Without Added Sugar",
        "body": "If plain water feels repetitive, infuse a pitcher with slices of cucumber, fresh mint, or a squeeze of lemon for a refreshing twist without sugary syrups.",
        "tag": "Taste",
    },
    {
        "title": "Pace Yourself Steadily",
        "body": "Sipping moderate amounts throughout the morning and afternoon is much more comfortable than trying to catch up on your entire daily goal right before bedtime.",
        "tag": "Pacing",
    },
    {
        "title": "Use Urine Colour as a Simple Check",
        "body": "Pale straw-coloured urine generally indicates comfortable everyday hydration, whereas dark amber often signals it is time for a refreshing glass of water.",
        "tag": "Self-Check",
    },
]
