"""WaterBuddy – Your Daily Hydration Companion.

Run with:  streamlit run app.py
Layout:    app.py (screens) | logic.py (maths & rules) | data.py (reference data)
"""

import html
from datetime import datetime

import pandas as pd
import streamlit as st

from data import (
    AGE_GROUPS,
    DEFAULT_AGE_GROUP,
    FOOD_DATA,
    HYDRATION_TIPS,
    INFUSE_INGREDIENTS,
)
from logic import (
    classify_food_hydration,
    compute_hydration_metrics,
    get_milestone_info,
    get_unlocked_achievements,
    validate_amount,
)

# ==============================================================================
# PAGE CONFIGURATION (must be the first Streamlit call)
# ==============================================================================
st.set_page_config(
    page_title="WaterBuddy – Your Daily Hydration Companion",
    page_icon="💧",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ==============================================================================
# SESSION STATE
# ==============================================================================
# Keys that belong to input widgets (text box, checkbox, slider ...).
# Streamlit deletes a widget's value when the widget is not drawn on the current
# page, so we copy these values back into session_state on every run.
WIDGET_KEYS = (
    "user_name",
    "Show_Math_Formulas",
    "custom_amount_input",
    "profile_age_selector",
    "manual_goal_slider",
)


def default_state():
    """Fresh defaults (a function so each session gets its own new list)."""
    return {
        "user_name": "Explorer",
        "age_group": DEFAULT_AGE_GROUP,
        "daily_goal": AGE_GROUPS[DEFAULT_AGE_GROUP]["goal"],
        "logs": [],  # list of {"id", "amount", "time", "note"}
        "next_log_id": 1,
        "custom_amount_input": 250,
        "tip_index": 0,
        "feedback_msg": "",
        "feedback_type": "info",
        "Show_Math_Formulas": True,
        "profile_age_selector": DEFAULT_AGE_GROUP,
        "manual_goal_slider": AGE_GROUPS[DEFAULT_AGE_GROUP]["goal"],
    }


def init_session_state():
    for key, value in default_state().items():
        if key not in st.session_state:
            st.session_state[key] = value


def keep_widget_state():
    for key in WIDGET_KEYS:
        st.session_state[key] = st.session_state[key]


init_session_state()
keep_widget_state()

# ==============================================================================
# CALLBACKS (run before the page redraws, so a click never logs twice)
# ==============================================================================
def add_water_entry(amount, label="Quick Sip"):
    value, error = validate_amount(amount)
    if error:
        st.session_state.feedback_msg = error
        st.session_state.feedback_type = "error"
        return

    now_str = datetime.now().strftime("%H:%M:%S")
    st.session_state.logs.append(
        {
            "id": st.session_state.next_log_id,
            "amount": value,
            "time": now_str,
            "note": label,
        }
    )
    st.session_state.next_log_id += 1
    st.session_state.feedback_msg = f"Logged +{value} ml ({label}) at {now_str}."
    st.session_state.feedback_type = "success"


def cb_quick_250():
    add_water_entry(250, "Quick +250 ml Glass")


def cb_custom_amount():
    add_water_entry(st.session_state.get("custom_amount_input", 250), "Custom Entry")


def cb_undo_last():
    if st.session_state.logs:
        removed = st.session_state.logs.pop()
        st.session_state.feedback_msg = (
            f"Undid last entry: -{removed['amount']} ml ({removed['time']})."
        )
        st.session_state.feedback_type = "info"
    else:
        st.session_state.feedback_msg = "No entries to undo yet."
        st.session_state.feedback_type = "warning"


def cb_reset_logs():
    st.session_state.logs = []
    st.session_state.next_log_id = 1
    st.session_state.feedback_msg = "Today's water log has been reset to 0 ml."
    st.session_state.feedback_type = "info"


def cb_next_tip():
    st.session_state.tip_index = (st.session_state.tip_index + 1) % len(HYDRATION_TIPS)


def cb_apply_age_preset():
    selected_age = st.session_state.profile_age_selector
    goal = AGE_GROUPS[selected_age]["goal"]
    st.session_state.age_group = selected_age
    st.session_state.daily_goal = goal
    st.session_state.manual_goal_slider = goal  # keep the slider in step
    st.session_state.feedback_msg = (
        f"Updated age group to '{selected_age}' with suggested goal {goal} ml."
    )
    st.session_state.feedback_type = "success"


def cb_update_manual_goal():
    new_goal = int(st.session_state.manual_goal_slider)
    if 500 <= new_goal <= 6000:
        st.session_state.daily_goal = new_goal
        st.session_state.feedback_msg = f"Daily goal updated to {new_goal} ml."
        st.session_state.feedback_type = "success"


# ==============================================================================
# STYLING & HTML COMPONENTS
# ==============================================================================
def render_html(markup):
    """Send HTML to Streamlit.

    Blank lines and indentation inside HTML can make Streamlit's markdown
    treat part of it as plain text or code, so we strip both first.
    """
    cleaned = "\n".join(line.strip() for line in markup.splitlines() if line.strip())
    st.markdown(cleaned, unsafe_allow_html=True)


def inject_custom_css():
    render_html(
        """
        <style>
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700;1,9..40,400..700&family=Fraunces:ital,opsz,wght@0,9..144,600..800;1,9..144,600..800&display=swap');

        :root {
            --navy: #0b2545;
            --teal: #0e7c9b;
            --aqua: #5ccfe6;
            --pale-bg: #f6fbfc;
            --card-bg: #ffffff;
            --text-main: #0b2545;
            --text-muted: #47627e;
        }

        /* Fonts: set on the app and on text elements only, NOT on span/div,
           because Streamlit's icons are drawn with a special icon font. */
        .stApp {
            background-color: var(--pale-bg);
            font-family: 'DM Sans', sans-serif;
            color: var(--text-main);
        }
        .stApp p, .stApp li, .stApp label {
            font-family: 'DM Sans', sans-serif;
        }
        h1, h2, h3, h4, .fraunces-title {
            font-family: 'Fraunces', serif !important;
            color: var(--navy);
            letter-spacing: -0.02em;
        }

        /* Sidebar */
        section[data-testid="stSidebar"] {
            background: linear-gradient(180deg, #0b2545 0%, #091d36 60%, #0e4c64 100%) !important;
            border-right: 1px solid rgba(92, 207, 230, 0.2);
        }
        section[data-testid="stSidebar"] * {
            color: #f6fbfc !important;
        }
        section[data-testid="stSidebar"] div[role="radiogroup"] > label {
            padding: 10px 14px !important;
            margin-bottom: 6px !important;
            border-radius: 10px !important;
            border-left: 4px solid transparent !important;
            transition: all 0.25s ease !important;
            background: rgba(255, 255, 255, 0.03) !important;
        }
        section[data-testid="stSidebar"] div[role="radiogroup"] > label:hover {
            background: rgba(92, 207, 230, 0.14) !important;
            transform: translateX(3px);
        }
        section[data-testid="stSidebar"] div[role="radiogroup"] > label:has(input:checked) {
            background: rgba(92, 207, 230, 0.22) !important;
            border-left: 4px solid #5ccfe6 !important;
            font-weight: 700 !important;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.18);
        }

        /* Cards */
        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(14px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .wb-card {
            background: var(--card-bg);
            border-radius: 18px;
            padding: 22px 24px;
            border: 1px solid rgba(14, 124, 155, 0.14);
            box-shadow: 0 6px 20px rgba(11, 37, 69, 0.05);
            animation: fadeUp 0.45s cubic-bezier(0.16, 1, 0.3, 1) both;
            transition: transform 0.25s ease, box-shadow 0.25s ease, border-color 0.25s ease;
            margin-bottom: 16px;
        }
        .wb-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 28px rgba(11, 37, 69, 0.10);
            border-color: rgba(92, 207, 230, 0.65);
        }

        /* Hero banner */
        .wb-hero {
            background: linear-gradient(135deg, #0b2545 0%, #0e7c9b 68%, #2ca6c4 100%);
            border-radius: 22px;
            padding: 28px 32px;
            color: #ffffff !important;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            box-shadow: 0 14px 32px rgba(11, 37, 69, 0.18);
            margin-bottom: 22px;
            animation: fadeUp 0.4s ease-out both;
        }
        .wb-hero h1, .wb-hero h2, .wb-hero p, .wb-hero span {
            color: #ffffff !important;
        }
        .wb-tagline-pill {
            display: inline-block;
            background: rgba(92, 207, 230, 0.22);
            border: 1px solid rgba(92, 207, 230, 0.55);
            color: #e0faff !important;
            padding: 4px 14px;
            border-radius: 999px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 10px;
        }

        /* Mascot: bobbing and blinking */
        @keyframes mascotBob {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-9px); }
        }
        @keyframes mascotBlink {
            0%, 92%, 100% { transform: scaleY(1); }
            96% { transform: scaleY(0.08); }
        }
        .mascot-svg {
            width: 120px;
            height: 140px;
            flex-shrink: 0;
            animation: mascotBob 3.2s ease-in-out infinite;
            filter: drop-shadow(0 10px 16px rgba(0, 0, 0, 0.25));
        }
        .mascot-eyes {
            transform-origin: center 68px;
            animation: mascotBlink 4.2s infinite;
        }

        /* Water bottle with moving wave */
        @keyframes waveSlide {
            0% { transform: translateX(0); }
            50% { transform: translateX(-25%); }
            100% { transform: translateX(-50%); }
        }
        .bottle-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 12px 0;
        }
        .bottle-cap {
            width: 48px;
            height: 16px;
            background: #0b2545;
            border-radius: 6px 6px 2px 2px;
            margin-bottom: 2px;
        }
        .bottle-neck {
            width: 62px;
            height: 18px;
            background: rgba(14, 124, 155, 0.18);
            border: 3px solid #0b2545;
            border-bottom: none;
            border-radius: 6px 6px 0 0;
        }
        .bottle-body {
            position: relative;
            width: 136px;
            height: 230px;
            background: #eef8fa;
            border: 4px solid #0b2545;
            border-radius: 26px 26px 32px 32px;
            overflow: hidden;
            box-shadow: inset 0 0 18px rgba(14, 124, 155, 0.14), 0 8px 20px rgba(11, 37, 69, 0.08);
        }
        .bottle-fill {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            background: linear-gradient(180deg, #5ccfe6 0%, #0e7c9b 100%);
            transition: height 0.7s cubic-bezier(0.22, 1, 0.36, 1);
        }
        .bottle-wave {
            position: absolute;
            top: -12px;
            left: 0;
            width: 200%;
            height: 24px;
            background: radial-gradient(circle at 50% 0%, transparent 45%, #5ccfe6 46%);
            background-size: 50% 24px;
            animation: waveSlide 3s linear infinite;
            opacity: 0.9;
        }
        .bottle-overlay-label {
            position: absolute;
            inset: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 3;
            font-weight: 700;
            color: #0b2545;
            text-shadow: 0 1px 6px rgba(255, 255, 255, 0.85);
            pointer-events: none;
        }

        /* Buttons: pill shape, full width, pulsing primary */
        @keyframes softPulse {
            0% { box-shadow: 0 0 0 0 rgba(14, 124, 155, 0.45); }
            70% { box-shadow: 0 0 0 12px rgba(14, 124, 155, 0); }
            100% { box-shadow: 0 0 0 0 rgba(14, 124, 155, 0); }
        }
        div.stButton > button {
            width: 100%;
            border-radius: 999px !important;
            padding: 0.55rem 1.35rem !important;
            font-weight: 600 !important;
            border: 1.5px solid #0e7c9b !important;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease !important;
        }
        div.stButton > button:hover {
            transform: translateY(-2px) !important;
            box-shadow: 0 6px 16px rgba(14, 124, 155, 0.22) !important;
        }
        div.stButton > button[kind="primary"] {
            background: linear-gradient(135deg, #0e7c9b 0%, #0b2545 100%) !important;
            color: #ffffff !important;
            border: none !important;
            animation: softPulse 2.4s infinite !important;
        }

        /* Progress bar */
        .wb-progress-track {
            width: 100%;
            height: 16px;
            background: #dceef2;
            border-radius: 999px;
            overflow: hidden;
            margin: 10px 0 6px 0;
        }
        .wb-progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #0e7c9b 0%, #5ccfe6 100%);
            border-radius: 999px;
            transition: width 0.6s ease;
        }

        /* Badges */
        .wb-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 999px;
            font-size: 0.8rem;
            font-weight: 700;
        }

        /* Mobile */
        @media (max-width: 768px) {
            .wb-hero { flex-direction: column; text-align: center; padding: 20px 18px; }
            .wb-card { padding: 16px 16px; }
        }
        </style>
        """
    )


def render_hero_banner(metrics, milestone_title, milestone_msg):
    """Navy-to-teal hero banner with the water-drop mascot."""
    pct = metrics["percentage"]
    # The mouth changes with progress
    if pct == 0:
        mouth_path = "M 48 92 Q 60 92 72 92"  # neutral
    elif pct < 50:
        mouth_path = "M 46 90 Q 60 98 74 90"  # small smile
    elif pct <= 100:
        mouth_path = "M 42 87 Q 60 104 78 87"  # big grin
    else:
        mouth_path = "M 52 90 Q 60 97 68 90"  # calm smile (goal exceeded)

    name = html.escape(st.session_state.user_name.strip() or "Explorer")
    age_group = html.escape(st.session_state.age_group)

    render_html(
        f"""
        <div class="wb-hero">
            <div style="flex: 1;">
                <span class="wb-tagline-pill">💧 Small sips. Better habits. • FA-2 Educational Project</span>
                <h1 style="margin: 4px 0 8px 0; font-size: 2.15rem;">WaterBuddy – Your Daily Hydration Companion</h1>
                <p style="margin: 0 0 12px 0; font-size: 1.02rem; opacity: 0.94;">
                    Hello, <strong>{name}</strong> ({age_group})!
                    <strong>{milestone_title}:</strong> {milestone_msg}
                </p>
                <div style="font-size: 0.84rem; opacity: 0.82;">
                    🔒 Session-only storage: your entries stay active across pages and reset when the browser tab closes. Not a medical device.
                </div>
            </div>
            <div>
                <svg class="mascot-svg" viewBox="0 0 120 140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="WaterBuddy mascot">
                    <defs>
                        <linearGradient id="dropGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#8be3f5" />
                            <stop offset="55%" stop-color="#5ccfe6" />
                            <stop offset="100%" stop-color="#0e7c9b" />
                        </linearGradient>
                    </defs>
                    <path d="M60 10 C60 10 108 66 108 96 C108 122 86.5 134 60 134 C33.5 134 12 122 12 96 C12 66 60 10 60 10 Z"
                          fill="url(#dropGrad)" stroke="#ffffff" stroke-width="3"/>
                    <path d="M40 52 C32 68 28 82 30 95" stroke="rgba(255,255,255,0.65)" stroke-width="5" stroke-linecap="round" fill="none"/>
                    <g class="mascot-eyes">
                        <circle cx="43" cy="72" r="5.5" fill="#0b2545"/>
                        <circle cx="77" cy="72" r="5.5" fill="#0b2545"/>
                        <circle cx="41" cy="70" r="2" fill="#ffffff"/>
                        <circle cx="75" cy="70" r="2" fill="#ffffff"/>
                    </g>
                    <ellipse cx="33" cy="82" rx="6" ry="3.5" fill="rgba(255, 138, 165, 0.45)"/>
                    <ellipse cx="87" cy="82" rx="6" ry="3.5" fill="rgba(255, 138, 165, 0.45)"/>
                    <path d="{mouth_path}" stroke="#0b2545" stroke-width="4" stroke-linecap="round" fill="none"/>
                </svg>
            </div>
        </div>
        """
    )


def render_water_bottle(metrics, extra_html=""):
    """Animated water bottle inside one card. The fill height stops at 100%."""
    render_html(
        f"""
        <div class="wb-card">
            <div class="bottle-wrapper">
                <div class="bottle-cap"></div>
                <div class="bottle-neck"></div>
                <div class="bottle-body">
                    <div class="bottle-fill" style="height: {metrics['visual_pct']}%;">
                        <div class="bottle-wave"></div>
                    </div>
                    <div class="bottle-overlay-label">
                        <span style="font-size: 1.45rem; font-family: 'Fraunces', serif;">{metrics['percentage']:.1f}%</span>
                        <span style="font-size: 0.78rem;">{metrics['total']} / {metrics['goal']} ml</span>
                    </div>
                </div>
                <div style="margin-top: 8px; font-size: 0.82rem; color: #47627e; text-align: center;">
                    Visual bar caps smoothly at 100%
                </div>
            </div>
            {extra_html}
        </div>
        """
    )


def render_progress_bar(metrics):
    render_html(
        f"""
        <div class="wb-card" style="padding: 16px 20px;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <span style="font-weight:700; color:#0b2545;">Daily Hydration Progress</span>
                <span style="font-weight:700; color:#0e7c9b;">{metrics['percentage']:.1f}% (Visual Bar: {metrics['visual_pct']:.0f}% / 100%)</span>
            </div>
            <div class="wb-progress-track">
                <div class="wb-progress-fill" style="width: {metrics['visual_pct']}%;"></div>
            </div>
            <div style="font-size:0.84rem; color:#47627e; display:flex; justify-content:space-between;">
                <span>Logged: <strong>{metrics['total']} ml</strong></span>
                <span>Remaining: <strong>{metrics['remaining']} ml</strong></span>
                <span>Goal: <strong>{metrics['goal']} ml</strong></span>
            </div>
        </div>
        """
    )


def stat_card(label, value, color=None):
    colour_css = f" color:{color};" if color else ""
    render_html(
        f"""
        <div class="wb-card">
            <div style="font-size:0.85rem; color:#47627e;">{label}</div>
            <div class="fraunces-title" style="font-size:1.85rem; margin-top:4px;{colour_css}">{value}</div>
        </div>
        """
    )


# ==============================================================================
# SIDEBAR NAVIGATION
# ==============================================================================
inject_custom_css()

PAGES = [
    "Dashboard",
    "Water Tracker",
    "My Progress",
    "Hydration Tips",
    "Hydration Impact Checker",
    "Infuse & Learn",
    "Unit Converter",
    "Achievements",
    "Profile & Daily Goal",
    "Settings",
]

metrics = compute_hydration_metrics(st.session_state.logs, st.session_state.daily_goal)
ms_title, ms_msg, ms_color = get_milestone_info(metrics["percentage"], metrics["total"])

with st.sidebar:
    render_html(
        """
        <div style="padding: 8px 4px 14px 4px; border-bottom: 1px solid rgba(92,207,230,0.25); margin-bottom: 14px;">
            <div style="font-family: 'Fraunces', serif; font-size: 1.5rem; font-weight: 700; color: #ffffff;">💧 WaterBuddy</div>
            <div style="font-size: 0.85rem; color: #5ccfe6; font-weight: 500;">Small sips. Better habits.</div>
        </div>
        """
    )

    selected_page = st.radio(
        "Navigate WaterBuddy",
        options=PAGES,
        key="nav_page_radio",
        label_visibility="collapsed",
    )

    render_html(
        f"""
        <div style="margin-top: 18px; padding: 14px; border-radius: 14px; background: rgba(255,255,255,0.07); border: 1px solid rgba(92,207,230,0.25);">
            <div style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.05em; color: #5ccfe6;">Today's Snapshot</div>
            <div style="font-size: 1.35rem; font-weight: 700; margin: 4px 0;">{metrics['total']} / {metrics['goal']} ml</div>
            <div style="font-size: 0.82rem; opacity: 0.88;">Progress: {metrics['percentage']:.1f}% • Entries: {len(st.session_state.logs)}</div>
        </div>
        <div style="margin-top: 12px; font-size: 0.76rem; opacity: 0.75; line-height: 1.4;">
            ℹ️ <strong>Educational Note:</strong> FA-2 school project. Data is stored in session memory only and is not medical advice.
        </div>
        """
    )

# One-time pop-up for messages created by button callbacks
if st.session_state.feedback_msg:
    toast_icon = {"error": "❌", "warning": "⚠️", "success": "✅"}.get(
        st.session_state.feedback_type, "ℹ️"
    )
    st.toast(st.session_state.feedback_msg, icon=toast_icon)
    st.session_state.feedback_msg = ""

# ==============================================================================
# PAGE 1: DASHBOARD
# ==============================================================================
if selected_page == "Dashboard":
    render_hero_banner(metrics, ms_title, ms_msg)

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        stat_card("Total Logged Today", f"{metrics['total']} ml")
    with c2:
        stat_card("Daily Target", f"{metrics['goal']} ml")
    with c3:
        stat_card("Remaining to Goal", f"{metrics['remaining']} ml")
    with c4:
        stat_card("Completion", f"{metrics['percentage']:.1f}%", color="#0e7c9b")

    render_progress_bar(metrics)

    col_left, col_right = st.columns([1.4, 1])
    with col_left:
        render_html(
            f"""
            <div class="wb-card">
                <h3 style="margin-top:0;">Quick Hydration Actions</h3>
                <p style="color:#47627e; margin-bottom:12px;">
                    Add a standard 250 ml glass with one click, or manage your session log below.
                </p>
                <div style="padding:10px 14px; border-radius:12px; background:#f0f9fb; border-left:4px solid {ms_color}; margin-bottom:10px;">
                    <strong>{ms_title}:</strong> {ms_msg}
                </div>
            </div>
            """
        )
        b1, b2, b3 = st.columns(3)
        with b1:
            st.button(
                "💧 +250 ml Quick Sip",
                key="dash_add_250_btn",
                type="primary",
                on_click=cb_quick_250,
            )
        with b2:
            st.button("↩️ Undo Last Entry", key="dash_undo_btn", on_click=cb_undo_last)
        with b3:
            st.button("🔄 Reset Today", key="dash_reset_btn", on_click=cb_reset_logs)

        if st.session_state.Show_Math_Formulas:
            render_html(
                f"""
                <div class="wb-card" style="margin-top:14px; font-size:0.88rem;">
                    <strong>📐 Live Hydration Maths Check:</strong><br/>
                    • <code>total</code> = {metrics['total']} ml<br/>
                    • <code>remaining = max(0, {metrics['goal']} - {metrics['total']})</code> = <strong>{metrics['remaining']} ml</strong><br/>
                    • <code>percentage = ({metrics['total']} / {metrics['goal']}) × 100</code> = <strong>{metrics['percentage']:.1f}%</strong> (visual bar capped at {metrics['visual_pct']:.0f}%)
                </div>
                """
            )

    with col_right:
        render_water_bottle(metrics)

# ==============================================================================
# PAGE 2: WATER TRACKER
# ==============================================================================
elif selected_page == "Water Tracker":
    st.markdown("<h1>Water Tracker</h1>", unsafe_allow_html=True)
    st.caption(
        "Log your sips accurately. Data is kept in session memory across page switches and resets when the tab closes."
    )

    render_progress_bar(metrics)

    t_col1, t_col2 = st.columns([1.3, 1])
    with t_col1:
        with st.container(border=True):
            st.subheader("Add Water Intake")
            st.write("Choose the pulsing +250 ml quick button or log a validated custom amount (1–2000 ml).")
            st.button(
                "💧 +250 ml Standard Glass",
                key="tracker_add_250_btn",
                type="primary",
                on_click=cb_quick_250,
            )
            st.markdown("#### Custom Amount (1 – 2000 ml)")
            st.number_input(
                "Enter custom amount in ml (1 to 2000 ml):",
                min_value=1,
                max_value=2000,
                step=50,
                key="custom_amount_input",
            )
            st.button(
                "➕ Log Custom Amount",
                key="tracker_add_custom_btn",
                on_click=cb_custom_amount,
            )
            u1, u2 = st.columns(2)
            with u1:
                st.button("↩️ Undo Last Entry", key="tracker_undo_btn", on_click=cb_undo_last)
            with u2:
                st.button("🔄 Reset Today's Log", key="tracker_reset_btn", on_click=cb_reset_logs)

    with t_col2:
        render_water_bottle(
            metrics,
            extra_html=(
                f"<div style='text-align:center; font-weight:600; color:{ms_color};'>{ms_title}</div>"
                f"<p style='text-align:center; font-size:0.88rem; color:#47627e;'>{ms_msg}</p>"
            ),
        )

    st.markdown("### Today's Session Log")
    if st.session_state.logs:
        df_logs = pd.DataFrame(st.session_state.logs)
        df_logs["Cumulative (ml)"] = df_logs["amount"].cumsum()
        df_display = df_logs.rename(
            columns={
                "id": "Entry #",
                "time": "Time Logged",
                "amount": "Amount (ml)",
                "note": "Entry Type",
            }
        )[["Entry #", "Time Logged", "Entry Type", "Amount (ml)", "Cumulative (ml)"]]
        st.dataframe(df_display, hide_index=True)
    else:
        st.info("No water entries logged yet in this session. Use +250 ml or a custom amount above to start!")

# ==============================================================================
# PAGE 3: MY PROGRESS
# ==============================================================================
elif selected_page == "My Progress":
    st.markdown("<h1>My Progress (Today's Session Only)</h1>", unsafe_allow_html=True)
    st.caption(
        "Transparent tracking: this page charts only your real entries from the current session—no simulated or fake multi-day history."
    )

    render_progress_bar(metrics)

    if not st.session_state.logs:
        render_html(
            """
            <div class="wb-card">
                <h3 style="margin-top:0;">No Entries Logged Yet Today</h3>
                <p style="color:#47627e;">
                    Head over to the <strong>Dashboard</strong> or <strong>Water Tracker</strong> and log your first sip to see your live session chart and statistics!
                </p>
            </div>
            """
        )
    else:
        df_prog = pd.DataFrame(st.session_state.logs)
        # Zero-padded numbers keep the chart in entry order (#02 before #10)
        df_prog["Entry Label"] = [
            f"#{row_id:02d} ({row_time})"
            for row_id, row_time in zip(df_prog["id"], df_prog["time"])
        ]
        df_prog["Cumulative Total (ml)"] = df_prog["amount"].cumsum()

        m1, m2, m3 = st.columns(3)
        with m1:
            st.metric("Entries Today", len(df_prog))
        with m2:
            st.metric("Average Sip Size", f"{df_prog['amount'].mean():.0f} ml")
        with m3:
            st.metric("Largest Single Entry", f"{df_prog['amount'].max()} ml")

        ch1, ch2 = st.columns(2)
        with ch1:
            st.markdown("#### Amount per Entry (ml)")
            st.bar_chart(df_prog.set_index("Entry Label")["amount"], color="#0e7c9b")
        with ch2:
            st.markdown("#### Cumulative Hydration Today (ml)")
            st.line_chart(
                df_prog.set_index("Entry Label")["Cumulative Total (ml)"],
                color="#5ccfe6",
            )

# ==============================================================================
# PAGE 4: HYDRATION TIPS
# ==============================================================================
elif selected_page == "Hydration Tips":
    st.markdown("<h1>Hydration Tips</h1>", unsafe_allow_html=True)
    st.caption("Practical, encouraging habits for students and families.")

    current_tip = HYDRATION_TIPS[st.session_state.tip_index]
    render_html(
        f"""
        <div class="wb-card" style="border-left: 6px solid #0e7c9b;">
            <span class="wb-badge" style="background:#e0f7fa; color:#0e7c9b; margin-bottom:10px;">
                Tip {st.session_state.tip_index + 1} of {len(HYDRATION_TIPS)} • {current_tip['tag']}
            </span>
            <h2 style="margin-top:6px;">{current_tip['title']}</h2>
            <p style="font-size:1.08rem; color:#0b2545; line-height:1.6;">{current_tip['body']}</p>
        </div>
        """
    )

    st.button(
        "✨ Show Another Tip",
        key="show_another_tip_btn",
        type="primary",
        on_click=cb_next_tip,
    )

    st.markdown("### All Everyday Hydration Principles")
    for idx, tip in enumerate(HYDRATION_TIPS, start=1):
        render_html(
            f"""
            <div class="wb-card" style="padding: 14px 18px;">
                <strong>{idx}. {tip['title']}</strong> <span style="color:#0e7c9b; font-size:0.82rem;">({tip['tag']})</span>
                <div style="color:#47627e; font-size:0.92rem; margin-top:4px;">{tip['body']}</div>
            </div>
            """
        )

# ==============================================================================
# PAGE 5: HYDRATION IMPACT CHECKER
# ==============================================================================
elif selected_page == "Hydration Impact Checker":
    st.markdown("<h1>Hydration Impact Checker</h1>", unsafe_allow_html=True)
    st.caption(
        "Explore how everyday foods and beverages contribute water to your diet. Values are based on USDA FoodData Central. "
        "Note: low-moisture foods still provide valuable nutrients and are never labelled 'dehydrating'."
    )

    f1, f2 = st.columns([2, 1])
    with f1:
        food_search = st.text_input(
            "🔍 Search food or drink (e.g., watermelon, cucumber, milk, dal, chips):",
            value="",
            key="food_search_input",
        )
    with f2:
        serving_g = st.number_input(
            "⚖️ Serving size (grams or ml):",
            min_value=10,
            max_value=1000,
            value=150,
            step=10,
            key="food_serving_input",
        )

    query = food_search.strip().lower()
    filtered_foods = [f for f in FOOD_DATA if query in f["name"].lower()]

    render_html(
        """
        <div style="font-size:0.86rem; color:#47627e; margin-bottom:14px;">
            <strong>Category Key:</strong>
            <span class="wb-badge" style="background:#ccfbf1; color:#0f766e;">≥90% Very High</span>
            <span class="wb-badge" style="background:#e0f2fe; color:#0369a1;">75–89% High</span>
            <span class="wb-badge" style="background:#fef3c7; color:#b45309;">40–74% Moderate</span>
            <span class="wb-badge" style="background:#f1f5f9; color:#475569;">&lt;40% Low</span>
        </div>
        """
    )

    if not filtered_foods:
        st.warning("No matching foods found. Try clearing your search term.")
    else:
        for food in filtered_foods:
            w_pct = food["water_pct"]
            cat_label, cat_color = classify_food_hydration(w_pct)
            cat_label = html.escape(cat_label)

            if w_pct is None:
                pct_str = "Data unavailable"
                est_ml_str = "Data unavailable"
                calc_str = "Data unavailable (water percentage not indexed for this custom dish)"
            else:
                est_ml = (serving_g * w_pct) / 100.0
                pct_str = f"{w_pct:.1f}%"
                est_ml_str = f"{est_ml:.1f} ml"
                calc_str = f"{serving_g} g × ({w_pct:.1f} / 100) = {est_ml:.1f} ml"

            render_html(
                f"""
                <div class="wb-card">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                        <h3 style="margin:0;">{food['name']}</h3>
                        <span class="wb-badge" style="background:rgba(14,124,155,0.12); color:{cat_color}; border:1px solid {cat_color};">Category: {cat_label}</span>
                    </div>
                    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap:12px; margin-top:12px;">
                        <div>
                            <div style="font-size:0.8rem; color:#47627e;">Water Content (%)</div>
                            <div style="font-size:1.15rem; font-weight:700;">{pct_str}</div>
                        </div>
                        <div>
                            <div style="font-size:0.8rem; color:#47627e;">Estimated Water (for {serving_g} g)</div>
                            <div style="font-size:1.15rem; font-weight:700; color:#0e7c9b;">{est_ml_str}</div>
                        </div>
                        <div>
                            <div style="font-size:0.8rem; color:#47627e;">Calculation Formula</div>
                            <div style="font-size:0.9rem; font-family:monospace;">{calc_str}</div>
                        </div>
                    </div>
                    <div style="margin-top:10px; font-size:0.8rem; color:#47627e;">
                        📚 Source: <a href="{food['source_url']}" target="_blank" style="color:#0e7c9b;">{food['source']}</a>
                    </div>
                </div>
                """
            )

# ==============================================================================
# PAGE 6: INFUSE & LEARN
# ==============================================================================
elif selected_page == "Infuse & Learn":
    st.markdown("<h1>Infuse &amp; Learn</h1>", unsafe_allow_html=True)
    st.caption(
        "Discover traditional Indian and kitchen water infusions. Every claim carries an explicit evidence tier "
        "(Well supported / Limited evidence / Insufficient evidence). Infused water supports pleasant hydration—it does not "
        "detox organs, cause weight loss, clear skin, or treat disease."
    )

    i1, i2 = st.columns([1.6, 1])
    with i1:
        inf_search = st.text_input(
            "🔍 Search ingredients (e.g., chia, saunf, jeera, lemon, mint, cucumber):",
            value="",
            key="infuse_search_input",
        )
    with i2:
        categories = ["All Categories"] + sorted({item["category"] for item in INFUSE_INGREDIENTS})
        inf_cat = st.selectbox("🗂️ Filter by Category:", options=categories, key="infuse_category_select")

    inf_query = inf_search.strip().lower()
    filtered_infuse = [
        item
        for item in INFUSE_INGREDIENTS
        if (inf_cat == "All Categories" or item["category"] == inf_cat)
        and (
            inf_query in item["name"].lower()
            or inf_query in item["taste"].lower()
            or inf_query in item["nutrients"].lower()
        )
    ]

    EVIDENCE_STYLES = {
        "Well supported": "background:#ccfbf1; color:#0f766e;",
        "Limited evidence": "background:#fef3c7; color:#b45309;",
        "Insufficient evidence": "background:#fee2e2; color:#b91c1c;",
    }

    if not filtered_infuse:
        st.warning("No ingredients match your current filter.")
    else:
        for item in filtered_infuse:
            claims_html = ""
            for c in item["claims"]:
                badge_style = EVIDENCE_STYLES[c["evidence"]]
                claims_html += (
                    f"<li style='margin-bottom:6px;'>"
                    f"<span class='wb-badge' style='{badge_style} margin-right:8px;'>{c['evidence']}</span>"
                    f"{c['claim']}</li>"
                )

            render_html(
                f"""
                <div class="wb-card">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <h3 style="margin:0;">🌿 {item['name']}</h3>
                        <span class="wb-badge" style="background:#e0f2fe; color:#0e7c9b;">{item['category']}</span>
                    </div>
                    <p style="margin:8px 0 4px 0;"><strong>Key Nutrients:</strong> {item['nutrients']}</p>
                    <p style="margin:4px 0;"><strong>Taste Profile:</strong> {item['taste']}</p>
                    <p style="margin:4px 0;"><strong>How to Use:</strong> {item['use']}</p>
                    <p style="margin:4px 0; color:#b45309;"><strong>⚠️ Precautions:</strong> {item['precautions']}</p>
                    <div style="margin-top:10px;">
                        <strong>Evidence-Graded Claims:</strong>
                        <ul style="margin-top:6px; padding-left:18px;">{claims_html}</ul>
                    </div>
                    <div style="font-size:0.82rem; margin-top:6px;">
                        🔗 Reference: <a href="{item['source_url']}" target="_blank" style="color:#0e7c9b;">{item['source_name']}</a>
                    </div>
                </div>
                """
            )

    st.markdown("---")
    st.markdown("### ⚖️ Compare Two Ingredients Side-by-Side")
    ing_names = [i["name"] for i in INFUSE_INGREDIENTS]
    cmp1, cmp2 = st.columns(2)
    with cmp1:
        comp_a_name = st.selectbox("Select First Ingredient:", options=ing_names, index=0, key="comp_ing_a")
    with cmp2:
        comp_b_name = st.selectbox("Select Second Ingredient:", options=ing_names, index=3, key="comp_ing_b")

    ing_a = next(i for i in INFUSE_INGREDIENTS if i["name"] == comp_a_name)
    ing_b = next(i for i in INFUSE_INGREDIENTS if i["name"] == comp_b_name)

    def compare_column(ing):
        return [
            ing["category"],
            ing["nutrients"],
            ing["taste"],
            ing["use"],
            ing["precautions"],
            ing["claims"][0]["claim"],
        ]

    comp_df = pd.DataFrame(
        {
            "Attribute": [
                "Category",
                "Nutrients",
                "Taste Profile",
                "How to Infuse",
                "Precautions",
                "Well-Supported Claim",
            ],
            # If both boxes pick the same ingredient the names clash, so label them A / B
            f"A: {ing_a['name']}": compare_column(ing_a),
            f"B: {ing_b['name']}": compare_column(ing_b),
        }
    )
    st.table(comp_df)

# ==============================================================================
# PAGE 7: UNIT CONVERTER
# ==============================================================================
elif selected_page == "Unit Converter":
    st.markdown("<h1>Hydration Unit Converter</h1>", unsafe_allow_html=True)
    st.caption(
        "Convert between millilitres (ml), litres (L), and standard cups. "
        "Assumed educational standard: 1 cup = 240 ml (1 L = 1000 ml)."
    )

    conv1, conv2 = st.columns(2)
    with conv1:
        with st.container(border=True):
            st.subheader("ml ↔ Litres (L)")
            ml_val = st.number_input(
                "Millilitres (ml):",
                min_value=0.0,
                max_value=20000.0,
                value=1600.0,
                step=100.0,
                key="conv_ml_to_l",
            )
            st.success(f"**{ml_val:,.1f} ml** = **{ml_val / 1000.0:,.3f} Litres** (`{ml_val} / 1000`)")

            l_val = st.number_input(
                "Litres (L):",
                min_value=0.0,
                max_value=20.0,
                value=2.5,
                step=0.25,
                key="conv_l_to_ml",
            )
            st.success(f"**{l_val:,.2f} Litres** = **{l_val * 1000.0:,.0f} ml** (`{l_val} × 1000`)")

    with conv2:
        with st.container(border=True):
            st.subheader("Cups ↔ ml (1 cup = 240 ml)")
            cups_val = st.number_input(
                "Standard Cups (240 ml each):",
                min_value=0.0,
                max_value=50.0,
                value=8.0,
                step=0.5,
                key="conv_cups_to_ml",
            )
            st.success(f"**{cups_val:,.2f} Cups** = **{cups_val * 240.0:,.0f} ml** (`{cups_val} × 240 ml`)")

            ml_for_cups = st.number_input(
                "Millilitres (ml) to Cups:",
                min_value=0.0,
                max_value=20000.0,
                value=2500.0,
                step=120.0,
                key="conv_ml_to_cups",
            )
            st.success(f"**{ml_for_cups:,.0f} ml** = **{ml_for_cups / 240.0:,.2f} Cups** (`{ml_for_cups} / 240 ml`)")

# ==============================================================================
# PAGE 8: ACHIEVEMENTS
# ==============================================================================
elif selected_page == "Achievements":
    st.markdown("<h1>Hydration Achievements</h1>", unsafe_allow_html=True)
    st.caption("Badges unlock dynamically from your real session data—never pre-populated or faked.")

    badges = get_unlocked_achievements(st.session_state.logs, metrics["percentage"])
    unlocked_count = sum(1 for b in badges if b["unlocked"])

    render_html(
        f"""
        <div class="wb-card">
            <strong>Unlocked in Current Session: {unlocked_count} / {len(badges)} Badges</strong>
            <div style="font-size:0.88rem; color:#47627e; margin-top:4px;">
                Current Progress: {metrics['total']} ml / {metrics['goal']} ml ({metrics['percentage']:.1f}%)
            </div>
        </div>
        """
    )

    for b in badges:
        status_badge = (
            '<span class="wb-badge" style="background:#ccfbf1; color:#0f766e;">✅ Unlocked</span>'
            if b["unlocked"]
            else '<span class="wb-badge" style="background:#f1f5f9; color:#64748b;">🔒 Locked</span>'
        )
        border_style = (
            "border-left: 6px solid #0e7c9b;"
            if b["unlocked"]
            else "border-left: 6px solid #cbd5e1; opacity: 0.78;"
        )
        render_html(
            f"""
            <div class="wb-card" style="{border_style}">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <h3 style="margin:0;">🏅 {b['title']}</h3>
                    {status_badge}
                </div>
                <p style="margin:6px 0; color:#47627e;">{b['desc']}</p>
                <div style="font-size:0.8rem; color:#0e7c9b;">Requirement: {b['rule']}</div>
            </div>
            """
        )

# ==============================================================================
# PAGE 9: PROFILE & DAILY GOAL
# ==============================================================================
elif selected_page == "Profile & Daily Goal":
    st.markdown("<h1>Profile &amp; Daily Goal</h1>", unsafe_allow_html=True)
    st.caption("Select an age-group reference goal or customise your target between 500 ml and 6000 ml.")

    with st.container(border=True):
        st.text_input("Your Display Name (Session Only):", key="user_name", max_chars=30)

        selected_age = st.selectbox(
            "Age Group (Educational Reference):",
            options=list(AGE_GROUPS.keys()),
            key="profile_age_selector",
        )
        st.info(AGE_GROUPS[selected_age]["note"])
        st.button(
            "Apply Suggested Age-Group Goal",
            key="apply_age_goal_btn",
            on_click=cb_apply_age_preset,
        )

    with st.container(border=True):
        st.markdown("### Custom Daily Goal (500 – 6000 ml)")
        st.slider(
            "Adjust your daily hydration goal (ml):",
            min_value=500,
            max_value=6000,
            step=50,
            key="manual_goal_slider",
        )
        st.button(
            "Save Custom Daily Goal",
            key="save_manual_goal_btn",
            type="primary",
            on_click=cb_update_manual_goal,
        )

    st.markdown("### Reference Table of Age-Group Goals")
    age_table_df = pd.DataFrame(
        [
            {
                "Age Group": name,
                "Suggested Daily Goal (ml)": info["goal"],
                "Educational Classification": info["note"],
            }
            for name, info in AGE_GROUPS.items()
        ]
    )
    st.table(age_table_df)

# ==============================================================================
# PAGE 10: SETTINGS
# ==============================================================================
elif selected_page == "Settings":
    st.markdown("<h1>Settings &amp; Project Transparency</h1>", unsafe_allow_html=True)
    st.caption("Configure display preferences and manage your session data.")

    with st.container(border=True):
        st.checkbox(
            "Show live hydration maths formulas on Dashboard",
            key="Show_Math_Formulas",
        )

    render_html(
        """
        <div class="wb-card">
            <h3 style="margin-top:0;">🔒 Session-Only Data &amp; Educational Disclaimer</h3>
            <p style="color:#47627e; line-height:1.6;">
                1. <strong>Session-Only Storage:</strong> WaterBuddy stores your logs, profile, and custom goals inside
                <code>st.session_state</code>. Your entries persist across all 10 pages while your browser tab is open,
                and reset when you close or refresh the browser tab.<br/>
                2. <strong>Educational Scope (FA-2):</strong> WaterBuddy is a school educational project designed to demonstrate
                healthy habits, nutrition data literacy, and Python/Streamlit engineering. It is not a medical device and does not
                provide clinical diagnosis or treatment advice.
            </p>
        </div>
        """
    )

    st.button(
        "🗑️ Reset All Today's Hydration Logs",
        key="settings_reset_logs_btn",
        on_click=cb_reset_logs,
    )
